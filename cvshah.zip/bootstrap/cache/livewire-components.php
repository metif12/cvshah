<?php return array (
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
  'auth.passwords.confirm' => 'App\\Http\\Livewire\\Auth\\Passwords\\Confirm',
  'auth.passwords.email' => 'App\\Http\\Livewire\\Auth\\Passwords\\Email',
  'auth.passwords.reset' => 'App\\Http\\Livewire\\Auth\\Passwords\\Reset',
  'auth.register' => 'App\\Http\\Livewire\\Auth\\Register',
  'auth.verify' => 'App\\Http\\Livewire\\Auth\\Verify',
  'components.list-item-demand' => 'App\\Http\\Livewire\\Components\\ListItemDemand',
  'panel.forms.add-demand' => 'App\\Http\\Livewire\\Panel\\Forms\\AddDemand',
  'panel.show-dashboard' => 'App\\Http\\Livewire\\Panel\\ShowDashboard',
);