<?php $attributes = $attributes->exceptProps(['route', 'content']); ?>
<?php foreach (array_filter((['route', 'content']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<li class="" x-data="{open: false}" @click.away="open=false">
    <button <?php echo e($attributes->merge(['class'=> (Request::routeIs($route) ? 'bg-gray-200' : '') . ' block flex items-center justify-center hover:bg-blue-100 p-2 w-full' ])); ?> @click="open = !open">
        <span class="flex-grow text-right"><?php echo e($slot); ?></span>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.icons.minus','data' => ['xShow' => 'open','style' => 'display: none','class' => 'w-4 h-4']]); ?>
<?php $component->withName('icons.minus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-show' => 'open','style' => 'display: none','class' => 'w-4 h-4']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.icons.plus','data' => ['xShow' => '!open','style' => 'display: none','class' => 'w-4 h-4']]); ?>
<?php $component->withName('icons.plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-show' => '!open','style' => 'display: none','class' => 'w-4 h-4']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </button>
    <div x-show="open" style="display: none" class="border-t-2 border-dashed">
        <?php echo e($content); ?>

    </div>
</li>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/nav/vertical-dropdown.blade.php ENDPATH**/ ?>