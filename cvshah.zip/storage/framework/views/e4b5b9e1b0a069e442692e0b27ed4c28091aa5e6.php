<div class="mt-2 flex flex-row-reverse flex-wrap">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/list/action-bar.blade.php ENDPATH**/ ?>