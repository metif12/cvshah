<input class="" <?php echo e($attributes); ?> type='file'/>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/form/file.blade.php ENDPATH**/ ?>