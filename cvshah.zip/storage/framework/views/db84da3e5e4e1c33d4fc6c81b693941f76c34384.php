<?php $attributes = $attributes->exceptProps(['id',]); ?>
<?php foreach (array_filter((['id',]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div x-data="{show: false}" x-show="show" <?php echo e('@' . $id); ?>.window.stop="show = $event.detail" <?php echo e($attributes->merge(['class'=>'inset-0 absolute z-10', 'style'=>'display=none;'])); ?>>
    <div class="fixed flex w-full h-full">
        <div class="w-4/5 md:w-1/3 lg:w-1/4 xl:w-1/5 bg-white border-l-1 border-gray-500" @click.away="show = false">
            <?php echo e($slot); ?>

        </div>
        <div class="flex-grow bg-black opacity-50"></div>
    </div>
</div>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/nav/mobile.blade.php ENDPATH**/ ?>