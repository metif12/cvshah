<label <?php echo e($attributes->merge(['class' => 'block font-medium text-sm text-gray-700'])); ?>>
    <?php echo e($slot); ?>

</label>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/form/label.blade.php ENDPATH**/ ?>