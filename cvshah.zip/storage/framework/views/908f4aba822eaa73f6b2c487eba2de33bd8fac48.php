<?php $attributes = $attributes->exceptProps(['title', 'color' => 'blue']); ?>
<?php foreach (array_filter((['title', 'color' => 'blue']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <dt class="sr-only"><?php echo e($title); ?></dt>
    <dd class="border border-<?php echo e($color); ?>-500 text-<?php echo e($color); ?>-500 rounded-md p-0.5 ml-1"><?php echo e($slot); ?></dd>
</div>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/list/badge.blade.php ENDPATH**/ ?>