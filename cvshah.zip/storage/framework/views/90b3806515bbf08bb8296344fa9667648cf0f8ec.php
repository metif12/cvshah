<?php $attributes = $attributes->exceptProps(['title','href']); ?>
<?php foreach (array_filter((['title','href']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<h3 class="flex flex-wrap text-gray-700 font-medium mt-2">
    <a class="flex-shrink-0 text-blue-500" href="<?php echo e($href); ?>">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.icons.home','data' => ['class' => 'inline w-5 h-5']]); ?>
<?php $component->withName('icons.home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'inline w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php echo e($title); ?>

    </a>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/breadcrumb/breadcrumb-bar.blade.php ENDPATH**/ ?>