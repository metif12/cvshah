<?php $attributes = $attributes->exceptProps(['type'=>'button', 'color'=>'blue', 'target'=>'' ]); ?>
<?php foreach (array_filter((['type'=>'button', 'color'=>'blue', 'target'=>'' ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<button wire:loading.attr="disabled" wire:target="<?php echo e($target); ?>" <?php echo e($attributes->merge(['type' => $type, 'class' => "flex items-center justify-center bg-$color-500 font-bold border border-transparent text-xs text-white uppercase hover:bg-$color-700 active:bg-$color-700 focus:outline-none focus:border-$color-200 focus:shadow-outline-$color disabled:opacity-25 transition ease-in-out duration-150"])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/button/button.blade.php ENDPATH**/ ?>