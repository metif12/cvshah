<nav <?php echo e($attributes->merge(['class'=>'p-2 md:p-4 bg-white p-2 shadow-md rounded-2xl'])); ?>>
    <ul class="flex flex-wrap items-center justify-center">
        <?php echo e($slot); ?>

    </ul>
</nav>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/nav/shortcut.blade.php ENDPATH**/ ?>