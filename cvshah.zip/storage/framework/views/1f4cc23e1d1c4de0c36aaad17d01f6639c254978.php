<?php $__env->startPush('scripts'); ?>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script>
        function reCaptchaCallback(response) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('g_recaptcha_response', response);
        }

        Livewire.on('resetReCaptcha', () => {
            grecaptcha.reset();
        });
    </script>
<?php $__env->stopPush(); ?>
<div class="mt-6">
    <div class="g-recaptcha flex items-center justify-center" data-sitekey="<?php echo e(config('services.google.recaptcha.key')); ?>" data-callback="reCaptchaCallback" wire:ignore></div>
    <input type="hidden" name="g_recaptcha_response" wire:model.lazy="g_recaptcha_response">
    <?php $__errorArgs = ['g_recaptcha_response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/google-recaptcha.blade.php ENDPATH**/ ?>