<dl class="mt-2 flex flex-wrap text-sm font-medium space-x-1">
    <?php echo e($slot); ?>

</dl>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/list/badge-bar.blade.php ENDPATH**/ ?>