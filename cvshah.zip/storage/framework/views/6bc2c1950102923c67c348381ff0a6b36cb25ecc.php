<?php $attributes = $attributes->exceptProps(['on', 'duration'=>3000, 'color'=>'gray']); ?>
<?php foreach (array_filter((['on', 'duration'=>3000, 'color'=>'gray']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div x-data="{ shown: false, timeout: null }"
     x-init="window.livewire.find('<?php echo e($_instance->id); ?>').on('<?php echo e($on); ?>', () => { clearTimeout(timeout); shown = true; timeout = setTimeout(() => { shown = false }, <?php echo e($duration); ?>);  })"
     x-show.transition.opacity.out.duration.1500ms="shown"
     style="display: none;"
    <?php echo e($attributes->merge(['class' => "text-sm text-$color"])); ?>>
    <?php echo e($slot ?? 'ذخیره شد.'); ?>

</div>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/form/action-message.blade.php ENDPATH**/ ?>