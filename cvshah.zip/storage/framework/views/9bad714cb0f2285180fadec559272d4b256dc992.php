<?php $attributes = $attributes->exceptProps([
'close_callback',
'show_condition',
]); ?>
<?php foreach (array_filter(([
'close_callback',
'show_condition',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="relative">
    <div
        <?php echo e($attributes->merge(['class'=>'flex flex-col flex-wrap top-0 left-0 z-20 bg-white text-gray-900 absolute rounded shadow-md py-2'])); ?>

        style="display: none"
        x-show="<?php echo $showCondition; ?>"
        @click.away="<?php echo $closeCallback; ?>"
        x-transition:enter="transition transform duration-300"
        x-transition:enter-start="opacity-0 scale-95"
        x-transition:enter-end="opacity-100 scale-100"
        x-transition:leave="transition transform duration-200"
        x-transition:leave-start="opacity-100 scale-100"
        x-transition:leave-end="opacity-0 scale-95"
    >
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/dropdown/dropdown.blade.php ENDPATH**/ ?>