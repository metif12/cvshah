<?php $attributes = $attributes->exceptProps(['title', 'desc'=>'', 'actions'=>'']); ?>
<?php foreach (array_filter((['title', 'desc'=>'', 'actions'=>'']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div <?php echo e($attributes->merge(['class'=>'bg-white rounded-md shadow overflow-hidden'])); ?>>
    <div class="px-2 lg:px-4 py-3 lg:py-5">
        <div class="mb-2 sm:px-0">
            <h3 class="text-lg font-medium text-gray-900"><?php echo e($title); ?></h3>
            <p class="mt-1 text-sm text-gray-600"><?php echo e($desc); ?></p>
        </div>
        <hr>
        <div class="mt-4">
            <?php echo e($slot); ?>

        </div>
    </div>
    <?php if($actions): ?>
        <div class="mt-4 flex items-center justify-end px-4 py-3 bg-gray-50 text-right sm:px-6">
            <?php echo e($actions); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/card/card.blade.php ENDPATH**/ ?>