<div class="w-full flex flex-wrap mb-4" x-data="{}">
    <?php echo e($right); ?>

    <div class="w-full my-1 md:my-0 md:w-0"></div>
    <div class="mr-auto flex">
        <div class="mx-auto"></div>
        <?php echo e($left); ?>

    </div>
</div>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/list/nav.blade.php ENDPATH**/ ?>