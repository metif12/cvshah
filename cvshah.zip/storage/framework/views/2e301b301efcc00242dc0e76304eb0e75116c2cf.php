<footer>
    <div class="md:m-8 bg-blue-400 p-4 shadow-md rounded-t-2xl md:rounded-b-2xl">
        <?php echo e($slot); ?>

    </div>
</footer>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/footer/footer.blade.php ENDPATH**/ ?>