<?php $attributes = $attributes->exceptProps(['name', 'value']); ?>
<?php foreach (array_filter((['name', 'value']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<label class="<?php echo e($attributes->merge(['class'=>'inline-block disabled:text-gray-500'])['class']); ?>">
    <input <?php echo e($attributes->except(['class','name', 'value'])); ?> name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" type="radio" class="form-radio h-5 w-5 disabled:bg-gray-200">
    <span class="mx-2"><?php echo e($slot); ?></span>
</label>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/form/radio.blade.php ENDPATH**/ ?>