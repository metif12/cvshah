<nav <?php echo e($attributes->merge(['class'=>'text-lg'])); ?>>
    <ul class="flex flex-wrap">
        <?php echo e($slot); ?>

    </ul>
</nav>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/nav/horizental.blade.php ENDPATH**/ ?>