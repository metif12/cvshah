<ul class="divide-y divide-gray-100">
    <?php echo e($slot); ?>

</ul>
<?php /**PATH C:\Users\Mahdi\PhpstormProjects\cvshah\resources\views/components/list/list.blade.php ENDPATH**/ ?>