@props(['title','href'])
<span class="flex-shrink-0 px-2">»</span><a href="{{$href}}" class="flex-shrink-0 text-blue-500">{{ $title }}</a>
