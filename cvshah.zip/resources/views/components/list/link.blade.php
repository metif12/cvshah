<x-button.link {{$attributes->merge(['class'=>'p-1 rounded-md'])}}>
    {{ $slot }}
</x-button.link>
