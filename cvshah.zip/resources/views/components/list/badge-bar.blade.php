<dl class="mt-2 flex flex-wrap text-sm font-medium space-x-1">
    {{ $slot }}
</dl>
