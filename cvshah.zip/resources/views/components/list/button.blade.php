<x-button.button {{$attributes->merge(['class'=>'p-1 rounded-md'])}}>
    {{ $slot }}
</x-button.button>
