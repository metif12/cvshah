<div class="mt-2 flex flex-row-reverse flex-wrap">
    {{ $slot }}
</div>
