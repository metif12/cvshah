<div class="flex w-full md:w-64 border-2 rounded-md">
    <input class="mx-auto form-input focus-within:outline-none disabled:bg-gray-200 disabled:text-gray-500">
    <x-icons.search class="my-2 ml-2 text-gray-400 w-4 h-4"/>
</div>
