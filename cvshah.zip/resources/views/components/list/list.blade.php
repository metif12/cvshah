<ul class="divide-y divide-gray-100">
    {{ $slot }}
</ul>
