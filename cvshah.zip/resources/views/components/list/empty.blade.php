<div class="h-64 m-5 p-5 flex items-center rounded-xl justify-center border">
    <p class="text-center text-gray-400 font-semibold">خالی!</p>
</div>
