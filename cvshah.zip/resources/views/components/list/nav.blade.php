<div class="w-full flex flex-wrap mb-4" x-data="{}">
    {{ $right }}
    <div class="w-full my-1 md:my-0 md:w-0"></div>
    <div class="mr-auto flex">
        <div class="mx-auto"></div>
        {{ $left }}
    </div>
</div>
