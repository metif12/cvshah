<li class=""><button {{ $attributes->merge(['class'=> 'flex hover:bg-blue-100 p-2 block w-full' ]) }}>{{ $slot }}</button></li>
