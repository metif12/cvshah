<footer>
    <div class="md:m-8 bg-blue-400 p-4 shadow-md rounded-t-2xl md:rounded-b-2xl">
        {{ $slot }}
    </div>
</footer>
